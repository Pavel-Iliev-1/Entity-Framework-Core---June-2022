﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Footballers.Data.Models.Enums
{
    public enum PositionType
    {
        Goalkeeper,
        Defender,
        Midfielder,
        Forward
    }
}
