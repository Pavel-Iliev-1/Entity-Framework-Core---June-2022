﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=Footballers;Trusted_Connection=True";
    }
}
