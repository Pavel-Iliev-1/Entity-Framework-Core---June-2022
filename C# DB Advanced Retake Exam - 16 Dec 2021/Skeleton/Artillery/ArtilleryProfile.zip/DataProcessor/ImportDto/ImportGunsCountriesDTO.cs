﻿
namespace Artillery.DataProcessor.ImportDto
{
   
    public class ImportGunsCountriesDTO
    {
        public int Id { get; set; }
    }
}
